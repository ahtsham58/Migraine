package com.mit.migraine;

/**
 * Created by cs on 9/27/2017.
 */

public class QuickMigraine {
    int hours;
    int minutes;
    int sleep_quality;
    int stress_level;
    String headache;
}
