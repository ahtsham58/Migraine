package com.mit.migraine;

/**
 * Created by cs on 6/1/2017.
 */

public interface DrawerLocker {
    public void setDrawerEnabled(boolean enabled);
}